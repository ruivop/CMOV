the android app for the Cafeteria Validation Terminal
