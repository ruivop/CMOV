the android app for the Ticket Validation Terminal
