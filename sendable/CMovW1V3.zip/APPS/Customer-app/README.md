the android app for the main user
